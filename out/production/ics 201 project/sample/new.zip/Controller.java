package sample;

import com.sun.xml.internal.bind.v2.runtime.unmarshaller.Loader;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.*;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Controller {
    @FXML MenuItem loadContact;
    @FXML Button PDF;
    @FXML ComboBox tags;
    @FXML TextArea message;
    @FXML Button start;
    @FXML TableView ContactTable;
    @FXML MenuItem viewcontact;
    @FXML TextField subject;


    ArrayList<ArrayList<String>> ContactList = new ArrayList<ArrayList<String>>();
    long number_of_Contacts;
    ObservableList<String> tags_list = FXCollections.observableArrayList();

    ArrayList<String> Merged_Message = new ArrayList<String>();


File file;
    public void setLoadcontacts(){

        FileChooser load_contacts = new FileChooser();

        load_contacts.setTitle("Load Contacts File");

        File thefile = load_contacts.showOpenDialog(new Stage());
        tags.setDisable(false);
        viewcontact.setDisable(false);
        message.setDisable(false);
        PDF.setDisable(false);
        start.setDisable(false);



        try {
            Path path = Paths.get(thefile.getAbsolutePath());
             number_of_Contacts = Files.lines(path).count()-1;

           // System.out.println(number_of_Contacts);
            Scanner input = new Scanner(new FileInputStream(thefile.getAbsolutePath()));

            StringTokenizer tag = new StringTokenizer(input.nextLine(),",");

            while (tag.hasMoreTokens()) {
                tags_list.add(tag.nextToken());

            }

            if (!tags_list.contains("[[EMAIL]]")){
                Alert missing_email = new Alert(Alert.AlertType.ERROR);
                missing_email.setTitle("missing Email ");
                missing_email.setContentText("Your file has no [[Email]] ");
                missing_email.show();
            }

            else {

                tags.setItems(tags_list);
                // checking the tags
            /*for (int i =0 ;i<tagsarray.length;i++){
                System.out.println("the element: "+tagsarray[i]);
            }*/


                for (int i = 0; i < number_of_Contacts; i++) {
                    StringTokenizer info = new StringTokenizer(input.nextLine(), ",");
                    ContactList.add(new ArrayList<String>());
                    for (int j = 0; j < tags_list.size(); j++) {
                        ContactList.get(i).add(info.nextToken());
                    }
                }



                tags.getSelectionModel().selectedItemProperty().addListener
                        ((v, oldValue, newValue) -> message.insertText(message.getCaretPosition(), (String) newValue));



            }

    } catch (IOException e) {
            e.printStackTrace();
        }

    }




    public void Merging(){
        for (int j = 0;j<number_of_Contacts;j++) {
            String msg = message.getText();
            for (int i=0 ;i<tags_list.size();i++){
                msg = msg.replace((String) tags_list.get(i), ContactList.get(j).get(i));
            }
            Merged_Message.add(msg);
        }






    }

    public void load_template(){

        FileChooser load_template = new FileChooser();
        load_template.setTitle("Load Contacts File");
        File thefile = load_template.showOpenDialog(new Stage());

        try {
            Scanner input = new Scanner(new FileInputStream(thefile.getAbsolutePath()));

            String Template="";
            while (input.hasNext()){
               Template+= input.nextLine()+"\n";
            }
            message.setText(Template);

        }catch (IOException e){

        }

    }

    public void save_Template(){
        if (message.getText().equals("")){
            Alert empty_Message =  new Alert(Alert.AlertType.ERROR) ;
            empty_Message.setContentText("you cant save the file");
            empty_Message.setTitle("Empty content");
            empty_Message.show();
        }
        else {

            FileChooser savefile = new FileChooser();
            File selectfile = savefile.showSaveDialog(new Stage());
            try {
                PrintWriter pw = new PrintWriter(new FileOutputStream(selectfile.getAbsolutePath()));
                pw.println(message.getText());
                pw.close();

                Alert saved = new Alert(Alert.AlertType.INFORMATION);
                saved.setTitle("Success");
                saved.setContentText("Your template has been saved successfully");
                saved.show();
            } catch (Exception e) {
                e.getMessage();
            }
        }
    }

    public void sendEmail(){
        Merging();
        int mailIndex = tags_list.indexOf("[[EMAIL]]");

        Platform.runLater(() -> {
            new PasswordDialog().start(new Stage());

            String userName = PasswordDialog.login.getUserName();
            String password = PasswordDialog.login.getPassword();



            //sends  email
            Alert alert;

            SendEmailOffice365 sender ;
            for (int i =0;i<number_of_Contacts;i++) {

                sender = new SendEmailOffice365(userName,password,ContactList.get(i).get(mailIndex),subject.getText(),Merged_Message.get(i));
                if (sender.sendEmail()) {

                    System.out.println("done");

                    }






                 else {

                    alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Login");
                    alert.setHeaderText("You have entered incorrect email or password");
                    alert.setContentText("Please try again");

                    alert.showAndWait();
                    break;
                }
            }


        });


















    }

    public void createPDF(){
        if (message.getText().equals("")) {
            Alert empty = new Alert(Alert.AlertType.ERROR);
            empty.setTitle("Empty Content");
            empty.setContentText("you cant  create empty pdf file ");
            empty.show();
        }
        else {

            Merging();
            if (MailMerge.makePDF(Merged_Message, number_of_Contacts)) {
                Alert pdf_done = new Alert(Alert.AlertType.INFORMATION);
                pdf_done.setTitle("Success");
                pdf_done.setContentText("pdf file created successfully");
                pdf_done.show();
            }
        }
    }

    public  void  viewContact()throws IOException{


        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Contactview.fxml"));
        Parent root1 = (Parent) fxmlLoader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root1));

        Contactview passcolumns = fxmlLoader.getController();


        for (int i=0 ;i<tags_list.size();i++){

            TableColumn column = new TableColumn(tags_list.get(i).substring(2,tags_list.get(i).length()-2));
           column.setResizable(true);
            passcolumns.setcolumns(column);
        }


        stage.show();

    }

}


