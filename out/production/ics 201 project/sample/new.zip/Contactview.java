package sample;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.util.ArrayList;

public class Contactview {
    @FXML
    private TableView ContactTable;


    public void setcolumns(TableColumn columns){
    this.ContactTable.getColumns().add(columns);



    }

    public void  setRows(TableView rows){

    }
}
